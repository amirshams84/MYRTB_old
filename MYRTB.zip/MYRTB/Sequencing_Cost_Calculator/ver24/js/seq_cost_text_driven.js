//############################################################################################################
//#######################################GTS Sequencing cost calculator#######################################
//############################################################################################################
//By: Amir Shams
//Date: OCT/14/2016 
//Time: 11:26:34
//############################################################################################################
var library_prep_array = [];
var accordion_string = '';
var sequencing_cost_array = [];
var instanse_name_of_sequencing_protocol = [];
var instanse_name_of_term_definition_array = [];
var term_definition_array = [];
var term_definition_array_length = 0;
//############################################################################################################
function loadSeqCost(data){
	sequencing_cost_array = data;
	var sequencing_cost_array_length = sequencing_cost_array.length;
	for(var sequencing_cost_array_index = 0; sequencing_cost_array_index < sequencing_cost_array_length; sequencing_cost_array_index++){
		instanse_name_of_sequencing_protocol.push(sequencing_cost_array[sequencing_cost_array_index]["sequencing_protocol"]);
	}
}
function loadTermDefinition(data){
	term_definition_array = data;
	term_definition_array_length = term_definition_array.length;
}
//############################################################################################################
function parseData(url, callBack) {
	Papa.parse(url, {
		header: true,
		download: true,
		dynamicTyping: true,
		complete: function(results) {
			if (results.errors.length != 0){
					var error_string = '';
					error_string = 'The Following file is a bad formatted file: ' + url + "\n";
					error_string += "Here is the problem that I found so far:\n";
					for (var i = 0; i< results.errors.length; i++){
						var index = i + 1;
						error_string += "Problem#" + index.toString() + ": " + results.errors[0]["message"] + "\n";
					}
					alert(error_string);
			}
			callBack(results.data);
		}
		});
}
//############################################################################################################
function loadAccordion(data) {
	//Data is usable here
	//console.log(data);
	library_prep_array = data;
	setTimeout(function(){
		var platform_array = [];
		var library_group_array = [];
		var library_prep_array_Length = library_prep_array.length;
		var total_platform_dictionary = {};
		var total_library_group = {};
		for(var each_library_index = 0; each_library_index < library_prep_array_Length; each_library_index++){
			var library_group_value = '';
			library_group_value = library_prep_array[each_library_index]["library_group"];
			if (total_library_group[library_group_value] == undefined){
				total_library_group[library_group_value] = [];
				total_library_group[library_group_value].push(library_prep_array[each_library_index]);
			}else{
				total_library_group[library_group_value].push(library_prep_array[each_library_index]);
			}
		}
		for (var each_library_group in total_library_group){
			var platform_value = '';
			platform_value = total_library_group[each_library_group][0]["platform"];
			if (total_platform_dictionary[platform_value] == undefined){
				total_platform_dictionary[platform_value] = [];
				total_platform_dictionary[platform_value].push(total_library_group[each_library_group]);

			}else{
				total_platform_dictionary[platform_value].push(total_library_group[each_library_group]);
			}
		}
		//the data loaded completely lets fill string
		var total_platform_keys = [];
		total_platform_keys = Object.keys(total_platform_dictionary);
		for (var each_platform in total_platform_dictionary){
			var platform_value = each_platform;
			var early_platform_string = '';
			var late_platform_string = '';
			early_platform_string += `
				<div id="` + slugify(platform_value) + `_MAIN_PANEL_GROUP" class="panel-group">
				<div id="` + slugify(platform_value) + `_MAIN_PANEL" class="panel panel-primary">
				<div id="` + slugify(platform_value) + `_MAIN_PANEL_HEADING" class="panel-heading">
				<h2 class="panel-title" style="font-family: 'Palanquin',sans-serif;font-size:13px;">` + platform_value + `</h2>
				</div><!-- END of ` + platform_value + `_MAIN_PANEL_HEADING -->
				<div id="COLLAPSE_` + platform_value + `_MAIN_PANEL_BODY" class="panel">
				<div id="` + slugify(platform_value) + `_MAIN_PANEL_BODY" class="panel-body">
				<div id="` + slugify(platform_value) + `_MAIN_PANEL_ACCORDION" class="panel-group">`;
				accordion_string += early_platform_string;
				late_platform_string += `</div><!-- END of ` + platform_value + `_MAIN_PANEL_ACCORDION -->
				</div><!-- END of ` + platform_value + `_MAIN_PANEL_BODY -->
				</div><!-- END of COLLAPSE_` + platform_value + `_MAIN_PANEL_BODY -->
				</div><!-- END of ` + platform_value + `_MAIN_PANEL -->
				</div><!-- END of ` + platform_value + `_MAIN_PANEL_GROUP -->\n\n\n`;
				//END OF PLATFORM
				//############################################################
				//LIBRARY GROUP
			for (var each_library_group_array_index in total_platform_dictionary[each_platform]){
				var library_group_array_value = total_platform_dictionary[each_platform][each_library_group_array_index][0]["library_group"];
				var library_group_definition = '';
				var library_group_web_link = '';
				var term_definition_dict = get_info_from_term(library_group_array_value);
				library_group_definition = term_definition_dict["description"];
				library_group_web_link = term_definition_dict["web_link"];
				var early_library_group_string = '';
				early_library_group_string += `<div id="` + slugify(library_group_array_value) + `_PANEL" class="panel panel-default">
					<div id="` + slugify(library_group_array_value) + `_PANEL_HEADING" class="panel-heading">
						<h3 class="panel-title" style="font-family: 'Palanquin',sans-serif;font-size:12px;">
							<a data-toggle="collapse" data-parent="#` + slugify(platform_value) + `_MAIN_PANEL_ACCORDION" href="#COLLAPSE_` + slugify(library_group_array_value) + `">` + library_group_array_value + ` <span class="fa fa-caret-down" style="font-size:11px;" aria-hidden="true"></span></a>
							<a data-toggle="collapse" href="#GINFO_` + slugify(library_group_array_value) + `"><span class="fa fa-question-circle fa-1x pull-right"></span></a>
							<div id="GINFO_` + slugify(library_group_array_value) + `" class="panel-collapse collapse" role="tabpanel"><p style="font-family: 'Palanquin',sans-serif;font-size:11px;">` + library_group_definition + `  <a href="` + library_group_web_link + `" target="_blank"><span class="fa fa-external-link-square" style="font-size:15px;" aria-hidden="true"></span></a></p></div>
						</h3>
					</div><!-- END OF ` + library_group_array_value + `_PANEL_HEADING -->
					<div id="COLLAPSE_` + slugify(library_group_array_value) + `" class="panel-collapse collapse">
						<div id="` + slugify(library_group_array_value) + `_PANEL_BODY" class="panel-body">
						<p style="font-family: 'Palanquin',sans-serif;font-size:11px;">The following products are currently available on our lab:</p>
						</div>
						<ul id="` + slugify(library_group_array_value) + `_PROTOCOL" class="list-group">`;
					accordion_string += early_library_group_string;
					var late_library_group_string = '';
					late_library_group_string += `</ul><!-- END of ` + library_group_array_value + `_PROTOCOL -->
										</div><!-- END of COLLAPSE_` + library_group_array_value + `" -->
									</div><!-- END OF ` + library_group_array_value + `_PANEL" -->\n\n\n`;
				//END OF LIBRARY GROUP
				//############################################################
				//LIBRARY
				for (var each_library in total_platform_dictionary[each_platform][each_library_group_array_index]){
					var library_prep_platform = '';
					library_prep_platform_value = total_platform_dictionary[each_platform][each_library_group_array_index][each_library]["library_prep_platform"];
					var library_prep_definition = '';
					var library_prep_web_link = '';
					var term_definition_dict = get_info_from_term(library_prep_platform_value);
					library_prep_definition = term_definition_dict["description"];
					library_prep_web_link = term_definition_dict["web_link"];
					var library_string = '';
					library_string += `\n
						<li id="` + slugify(library_prep_platform_value) + `" class="list-group-item" style="font-family: 'Palanquin',sans-serif;font-size:11px;">
							<a id ="LINK_` + slugify(library_prep_platform_value) + `" data-toggle="collapse" href="#CALCS_` + slugify(library_prep_platform_value) + `" onclick="merge_table_with_html('` + library_prep_platform_value + `', ` + slugify(library_prep_platform_value) + `_sample_quantity.value, ` + slugify(library_prep_platform_value) + `_run_quantity.value, '` + slugify(library_prep_platform_value) + `_table')">` + library_prep_platform_value + ` <span class="fa fa-caret-down" style="font-size:10px;" aria-hidden="true"></span></a>
							<a data-toggle="collapse" href="#INFO_` + slugify(library_prep_platform_value) + `" aria-expanded="true" aria-controls="INFO_` + slugify(library_prep_platform_value) + `"><span class="fa fa-question-circle fa-1x pull-right"></span></a>
							<div id="INFO_` + slugify(library_prep_platform_value) + `" class="panel-collapse collapse" role="tabpanel" aria-labelledby="INFO_` + slugify(library_prep_platform_value) + `"><p style="font-family: 'Palanquin',sans-serif;font-size:11px;">` + library_prep_definition + `  <a href="` + library_prep_web_link+ `" target="_blank"><span class="fa fa-external-link-square" style="font-size:13px;" aria-hidden="true"></span></a></p></div>
						</li><!-- END of ` + slugify(library_prep_platform_value) + ` -->
						<div id="CALCS_` + slugify(library_prep_platform_value) + `" class="panel-collapse collapse" style="font-family: 'Palanquin',sans-serif;font-size:11px;">
							<div class="panel-heading">
								<div class="form-inline" role="form">
									<div class="form-group">
										<label for="sample_quantity"><p>Samples requested:</p></label>
										<input type="text" class="form-control input-sm" id="` + slugify(library_prep_platform_value) + `_sample_quantity" value=20>
									</div>
									<div class="form-group">
										<label for="run_quantity"><p>Runs requested:</p></label>
										<input type="text" class="form-control input-sm input-sm" id="` + slugify(library_prep_platform_value) + `_run_quantity" value=1>
									</div>
									<button type="button" class="btn btn-sm btn-info" onclick="merge_table_with_html('` + library_prep_platform_value + `', ` + slugify(library_prep_platform_value) + `_sample_quantity.value, ` + slugify(library_prep_platform_value) + `_run_quantity.value, '` + slugify(library_prep_platform_value) + `_table')">Update</button>
								</div>
							</div>

							<div class="panel-body">
							</div>
							<!-- Table -->
							<div class="table-responsive">
								<table id="` + slugify(library_prep_platform_value) + `_table" class="table table-striped table-bordered small">
								<thead>
								<tr>
									<!--th><p class="text-center">#</p></th-->
									<th><p class="text-center">Sequencing protocol</p></th>
									<th><p class="text-center">Library Prep. Method</p></th>
									<th><p class="text-center">Sample requested</p></th>
									<th><p class="text-center">Runs required</p></th>
									<!--th><p class="text-center">Total SNS sequencing</p></th>
									<th><p class="text-center">Total RTB sequencing</p></th>
									<th><p class="text-center">Total RTB analysis</p></th-->
									<th><p class="text-center">Total</p></th>
									<th><p class="text-center">Total per sample</p></th>
									<th><p class="text-center">Million reads per sample</p></th>
								</tr>
								</thead>
								</table>
							</div>
						</div><!-- END of CALCS_` + library_prep_platform_value + ` -->`;
						accordion_string += library_string;
				}//library loop
				accordion_string += late_library_group_string;
			}//library_group_loop
				accordion_string += late_platform_string;
			}//platform loop
			//console.log(accordion_string);
			var container_div =document.getElementById("CONTAINER");
			container_div.insertAdjacentHTML( 'beforeend', accordion_string);
	},10);
}
//############################################################################################################
//depricated
function load_library_prep_cost_from_text(){
	var library_prep_object_dictionary = {};
	d3.tsv("./library_perp_cost.txt", function (data) {
		data.forEach(function (d,i) {//read csv file line by line key is header value is each column
			for(var j=0; j < d3.keys(data[0]).length; j++){
				library_prep_object_dictionary[d3.keys(data[0])[j]]=[];
			}
		});
		data.forEach(function (d,i) {//read csv file line by line key is header value is each column
			for(var j=0; j < d3.keys(data[i]).length; j++){
				library_prep_object_dictionary[d3.keys(data[0])[j]].push(d3.values(data[i])[j]);
			}
		});
		library_prep_object_dictionary_keys = [];
		library_prep_object_dictionary_keys = Object.keys(library_prep_object_dictionary);
		library_length = library_prep_object_dictionary[library_prep_object_dictionary_keys[0]].length;
		entry_length = library_prep_object_dictionary_keys.length;

		for (var each_library = 0; each_library < library_length; each_library++){
			cost_dict = {};
			for (var each_index = 0; each_index < entry_length; each_index++){
				if(isFloat(library_prep_object_dictionary[library_prep_object_dictionary_keys[each_index]][each_library]) == false){
					cost_dict[library_prep_object_dictionary_keys[each_index]] = library_prep_object_dictionary[library_prep_object_dictionary_keys[each_index]][each_library];
				} else {
					cost_dict[library_prep_object_dictionary_keys[each_index]] = parseFloat(library_prep_object_dictionary[library_prep_object_dictionary_keys[each_index]][each_library]);
				}
			}
			library_prep_array.push(cost_dict);
		}
	});
	//Since the asychronicity we use this to call back
	setTimeout(function(){
		var platform_array = [];
		var library_group_array = [];
		var library_prep_array_Length = library_prep_array.length;
		var total_platform_dictionary = {};
		var total_library_group = {};
		for(var each_library_index = 0; each_library_index < library_prep_array_Length; each_library_index++){
			var library_group_value = '';
			library_group_value = library_prep_array[each_library_index]["library_group"];
			if (total_library_group[library_group_value] == undefined){
				total_library_group[library_group_value] = [];
				total_library_group[library_group_value].push(library_prep_array[each_library_index]);
			}else{
				total_library_group[library_group_value].push(library_prep_array[each_library_index]);
			}
		}
		for (var each_library_group in total_library_group){
			var platform_value = '';
			platform_value = total_library_group[each_library_group][0]["platform"];
			if (total_platform_dictionary[platform_value] == undefined){
				total_platform_dictionary[platform_value] = [];
				total_platform_dictionary[platform_value].push(total_library_group[each_library_group]);

			}else{
				total_platform_dictionary[platform_value].push(total_library_group[each_library_group]);
			}
		}
		//the data loaded completely lets fill string
		var total_platform_keys = [];
		total_platform_keys = Object.keys(total_platform_dictionary);
		for (var each_platform in total_platform_dictionary){
			var platform_value = each_platform;
			var early_platform_string = '';
			var late_platform_string = '';
			early_platform_string += `
				<div id="` + slugify(platform_value) + `_MAIN_PANEL_GROUP" class="panel-group">
				<div id="` + slugify(platform_value) + `_MAIN_PANEL" class="panel panel-primary">
				<div id="` + slugify(platform_value) + `_MAIN_PANEL_HEADING" class="panel-heading">
				<h2 class="panel-title" style="font-size:12px;">` + platform_value + `</h2>
				</div><!-- END of ` + platform_value + `_MAIN_PANEL_HEADING -->
				<div id="COLLAPSE_` + platform_value + `_MAIN_PANEL_BODY" class="panel">
				<div id="` + slugify(platform_value) + `_MAIN_PANEL_BODY" class="panel-body">
				<div id="` + slugify(platform_value) + `_MAIN_PANEL_ACCORDION" class="panel-group">`;
				accordion_string += early_platform_string;
				late_platform_string += `</div><!-- END of ` + platform_value + `_MAIN_PANEL_ACCORDION -->
				</div><!-- END of ` + platform_value + `_MAIN_PANEL_BODY -->
				</div><!-- END of COLLAPSE_` + platform_value + `_MAIN_PANEL_BODY -->
				</div><!-- END of ` + platform_value + `_MAIN_PANEL -->
				</div><!-- END of ` + platform_value + `_MAIN_PANEL_GROUP -->\n\n\n`;
				//END OF PLATFORM
				//############################################################
				//LIBRARY GROUP
			for (var each_library_group_array_index in total_platform_dictionary[each_platform]){
				var library_group_array_value = total_platform_dictionary[each_platform][each_library_group_array_index][0]["library_group"];
				var early_library_group_string = '';
				early_library_group_string += `<div id="` + slugify(library_group_array_value) + `_PANEL" class="panel panel-default">
					<div id="` + slugify(library_group_array_value) + `_PANEL_HEADING" class="panel-heading">
						<h3 class="panel-title" style="font-size:11px;">
							<a data-toggle="collapse" data-parent="#` + slugify(platform_value) + `_MAIN_PANEL_ACCORDION" href="#COLLAPSE_` + slugify(library_group_array_value) + `">` + library_group_array_value + ` <span class="fa fa-caret-down" style="font-size:10px;" aria-hidden="true"></span></a>
							<a data-toggle="collapse" href="#INFO_` + slugify(library_group_array_value) + `"><span class="fa fa-question-circle fa-1x pull-right"></span></a> 
							<div id="INFO_` + slugify(library_group_array_value) + `" class="panel-collapse collapse" role="tabpanel"><p>Empthy FOR NOW!!!!</p></div>
						</h3>
					</div><!-- END OF ` + library_group_array_value + `_PANEL_HEADING -->
					<div id="COLLAPSE_` + slugify(library_group_array_value) + `" class="panel-collapse collapse">
						<div id="` + slugify(library_group_array_value) + `_PANEL_BODY" class="panel-body">
						<p>The following products are currently available on our lab:</p>
						</div>
						<ul id="` + slugify(library_group_array_value) + `_PROTOCOL" class="list-group">`;
					accordion_string += early_library_group_string;
					var late_library_group_string = '';
					late_library_group_string += `</ul><!-- END of ` + library_group_array_value + `_PROTOCOL -->
										</div><!-- END of COLLAPSE_` + library_group_array_value + `" -->
									</div><!-- END OF ` + library_group_array_value + `_PANEL" -->\n\n\n`;
				//END OF LIBRARY GROUP
				//############################################################
				//LIBRARY
				for (var each_library in total_platform_dictionary[each_platform][each_library_group_array_index]){
					var library_prep_platform = '';
					library_prep_platform_value = total_platform_dictionary[each_platform][each_library_group_array_index][each_library]["library_prep_platform"];
					var library_string = '';
					library_string += `\n
						<li id="` + slugify(library_prep_platform_value) + `" class="list-group-item">
							<a id ="LINK_` + slugify(library_prep_platform_value) + `" data-toggle="collapse" href="#CALCS_` + slugify(library_prep_platform_value) + `" onclick="merge_table_with_html('` + library_prep_platform_value + `', ` + slugify(library_prep_platform_value) + `_sample_quantity.value, ` + slugify(library_prep_platform_value) + `_run_quantity.value, '` + slugify(library_prep_platform_value) + `_table')">` + library_prep_platform_value + ` <span class="fa fa-caret-down" style="font-size:10px;" aria-hidden="true"></span></a>
							<a data-toggle="collapse" href="#INFO_` + slugify(library_prep_platform_value) + `" aria-expanded="true" aria-controls="INFO_` + slugify(library_prep_platform_value) + `"><span class="fa fa-question-circle fa-1x pull-right"></span></a> 
							<div id="INFO_` + slugify(library_prep_platform_value) + `" class="panel-collapse collapse" role="tabpanel" aria-labelledby="INFO_` + slugify(library_prep_platform_value) + `"><p>EMPTY FOR NOW!!!!!</p></div>
						</li><!-- END of ` + slugify(library_prep_platform_value) + ` -->
						<div id="CALCS_` + slugify(library_prep_platform_value) + `" class="panel-collapse collapse">
							<div class="panel-heading">
								<div class="form-inline" role="form">
									<div class="form-group">
										<label for="sample_quantity"><p>Samples requested:</p></label>
										<input type="text" class="form-control input-sm" id="` + slugify(library_prep_platform_value) + `_sample_quantity" value=20>
									</div>
									<div class="form-group">
										<label for="run_quantity"><p>Runs requested:</p></label>
										<input type="text" class="form-control input-sm input-sm" id="` + slugify(library_prep_platform_value) + `_run_quantity" value=1>
									</div>
									<button type="button" class="btn btn-sm btn-info" onclick="merge_table_with_html('` + library_prep_platform_value + `', ` + slugify(library_prep_platform_value) + `_sample_quantity.value, ` + slugify(library_prep_platform_value) + `_run_quantity.value, '` + slugify(library_prep_platform_value) + `_table')">Update</button>
								</div>
							</div>

							<div class="panel-body">
							</div>
							<!-- Table -->
							<div class="table-responsive">
								<table id="` + slugify(library_prep_platform_value) + `_table" class="table table-striped table-bordered small">
								<thead> 
								<tr> 
									<!--th><p class="text-center">#</p></th--> 
									<th><p class="text-center">Sequencing protocol</p></th>
									<th><p class="text-center">Library Prep. Method</p></th> 
									<th><p class="text-center">Sample requested</p></th> 
									<th><p class="text-center">Runs required</p></th>
									<!--th><p class="text-center">Total SNS sequencing</p></th>
									<th><p class="text-center">Total RTB sequencing</p></th>
									<th><p class="text-center">Total RTB analysis</p></th-->
									<th><p class="text-center">Total</p></th>
									<th><p class="text-center">Total per sample</p></th>
									<th><p class="text-center">Million reads per sample</p></th>
								</tr> 
								</thead> 
								</table>
							</div>
						</div><!-- END of CALCS_` + library_prep_platform_value + ` -->`;
						accordion_string += library_string;
				}//library loop
				accordion_string += late_library_group_string;
			}//library_group_loop
				accordion_string += late_platform_string;
			}//platform loop
			console.log(accordion_string);
			var container_div =document.getElementById("CONTAINER");
			container_div.insertAdjacentHTML( 'beforeend', accordion_string);
	},10);
}

//############################################################################################################
//depricated
function load_sequencing_cost_from_text(){
	var sequencing_cost_object_dictionary = {};
	d3.tsv("./sequencing_cost.txt", function (data) {
		data.forEach(function (d,i) {//read csv file line by line key is header value is each column
			for(var j=0; j < d3.keys(data[0]).length; j++){
				sequencing_cost_object_dictionary[d3.keys(data[0])[j]]=[];
			}
		});
		data.forEach(function (d,i) {//read csv file line by line key is header value is each column
			for(var j=0; j < d3.keys(data[i]).length; j++){
				sequencing_cost_object_dictionary[d3.keys(data[0])[j]].push(d3.values(data[i])[j]);
			}
		});
		sequencing_cost_object_dictionary_keys = [];
		sequencing_cost_object_dictionary_keys = Object.keys(sequencing_cost_object_dictionary);
		sequencing_cost_length = sequencing_cost_object_dictionary[sequencing_cost_object_dictionary_keys[0]].length;
		entry_length = sequencing_cost_object_dictionary_keys.length;

		for (var each_library = 0; each_library < sequencing_cost_length; each_library++){
			cost_dict = {};
			for (var each_index = 0; each_index < entry_length; each_index++){
				if(isFloat(sequencing_cost_object_dictionary[sequencing_cost_object_dictionary_keys[each_index]][each_library]) == false){
					cost_dict[sequencing_cost_object_dictionary_keys[each_index]] = sequencing_cost_object_dictionary[sequencing_cost_object_dictionary_keys[each_index]][each_library];
					
				} else {
					cost_dict[sequencing_cost_object_dictionary_keys[each_index]] = parseFloat(sequencing_cost_object_dictionary[sequencing_cost_object_dictionary_keys[each_index]][each_library]);
				}
			}
			sequencing_cost_array.push(cost_dict);
			instanse_name_of_sequencing_protocol.push(cost_dict["sequencing_protocol"]);
		}
	});

}
//############################################################################################################
function slugify(text){
	if(/^[0-9]/.test(text) == true)text = '_' + text
	return text.toString().trim()
	.replace(/\-/g, '_')
	.replace(/\s+/g, '_')           // Replace spaces with -
	.replace(/[^\w\-]+/g, '_')       // Remove all non-word chars
	.replace(/^-+/, '')             // Trim - from start of text
	.replace(/&/g, '_and_')
	.replace(/-+$/, '')            // Trim - from end of text
	.replace(/\_\_+/g, '_');         // Replace multiple - with single -
}

function isInArray(value, array) {
	return array.indexOf(value) > -1;
}
//############################################################################################################
function get_library_prep_cost_dictionary(library_prep_platform){
	var library_prep_cost_dictionary = {};
	for(var i = 0; i < library_prep_array.length; i++){
		if (library_prep_platform.localeCompare(library_prep_array[i]["library_prep_platform"]) == 0){
			library_prep_cost_dictionary = library_prep_array[i];
			break;
		}
	}
	return library_prep_cost_dictionary;

	}
//############################################################################################################
function get_sequencing_cost_dictionary(sequencing_protocol){
	var sequencing_cost_object_dictionary = {};
	var keys  = Object.keys(sequencing_cost_array);
	for(var i=0;i<keys.length;i++){
		if (sequencing_protocol == sequencing_cost_array[i]["sequencing_protocol"]){
			sequencing_cost_object_dictionary =  sequencing_cost_array[i];
		}
	}
	return sequencing_cost_object_dictionary;
}
//############################################################################################################
function merge_table_with_html(library_prep_platform, sample_quantity, run_quantity, table_id){
	//Removing existing table element
	//console.log(library_prep_platform);
	var elem =document.getElementById(table_id).lastChild;
		elem.parentNode.removeChild(elem);
	
	var table_body_code = generate_table(library_prep_platform, sample_quantity, run_quantity);
	//document.getElementById(table_id).getElementsByTagName('tbody')[0] = table_body_code;
	document.getElementById(table_id).appendChild(table_body_code);
}
//############################################################################################################
function generate_table(library_prep_platform, sample_quantity, run_quantity){
	var library_prep_platform_dictionary = {}
	library_prep_platform_dictionary = get_library_prep_cost_dictionary(library_prep_platform);
	//load into memory variables name dynamically
	for(var library_prep_platform_dictionary_key in library_prep_platform_dictionary) {
		window[library_prep_platform_dictionary_key] = library_prep_platform_dictionary[library_prep_platform_dictionary_key];
	}
	var html_tbdy = document.createElement("tbody");
		//html_tbdy.style.fontSize = "small";
	var optional_protocol_array = [];
	optional_protocol_array = library_prep_platform_dictionary["optional_protocol"].split(";");
	if(isInArray(library_prep_platform_dictionary["optimal_protocol"], optional_protocol_array)==false){
		optional_protocol_array.push(library_prep_platform_dictionary["optimal_protocol"]);
	}
	
	var optional_protocol_length = optional_protocol_array.length;
	for(var sequencing_protocol_index = 0; sequencing_protocol_index < optional_protocol_length; sequencing_protocol_index++){
			var html_tr = document.createElement("tr");
			if (library_prep_platform_dictionary["optimal_protocol"] == optional_protocol_array[sequencing_protocol_index]){
				html_tr.style.backgroundColor = 'yellow';
			}
			//console.log(instanse_name_of_Sequencing_protocol[each_protocol_index]);
			var cells = [];  
			var calcs = [];
			var actual_cost_array = [];
			actual_cost_array = calculate_actual_cost(library_prep_platform, sample_quantity, run_quantity, sequencing_protocol_index, optional_protocol_array[sequencing_protocol_index]);
			//console.log(actual_cost_array)
			var calcs_length = actual_cost_array.length;
			for (var i=0; i <calcs_length; i++){
				if (isFloat(actual_cost_array[i]) ){
					if (i > 3 & i < calcs_length - 1 ){
						cells.push('$' + commafy(actual_cost_array[i]));
					}
					else{

						cells.push(commafy(actual_cost_array[i]));
					}
				}
				else{
					cells.push(actual_cost_array[i]);
				}
			}
			
			for(var j=0;j < cells.length;j++){
				var html_td = document.createElement("td");
					html_td.appendChild(document.createTextNode(cells[j]))
					html_td.style.textAlign = "center";
					html_tr.appendChild(html_td);
					
			}
			
			html_tbdy.appendChild(html_tr);
		};
	return html_tbdy;

}
//############################################################################################################
function calculate_actual_cost(library_prep_platform, sample_quantity, run_quantity, sequencing_protocol_index, sequencing_protocol){
	//########################################
	//conversion
	sample_quantity = parseInt(sample_quantity);
	run_quantity = parseInt(run_quantity);
	//########################################
	//Dynamic variable loader
	var library_prep_platform_dictionary = get_library_prep_cost_dictionary(library_prep_platform);
	
	for(var library_prep_platform_dictionary_key in library_prep_platform_dictionary) {
		window[library_prep_platform_dictionary_key] = library_prep_platform_dictionary[library_prep_platform_dictionary_key];
	}
	var sequencing_protocol_dictionary = get_sequencing_cost_dictionary(sequencing_protocol);
	for(var sequencing_protocol_dictionary_key in sequencing_protocol_dictionary) {
		window[sequencing_protocol_dictionary_key] = sequencing_protocol_dictionary[sequencing_protocol_dictionary_key];
	}
	//#######################################
	//Main Calculation section
	//kit_samples = sample_quantity + kit_waste_premium * MOD(library_reagent_batch_size - sample_quantity, library_reagent_batch_size)
	var corrected_mod = correct_mod(( library_reagent_batch_size - sample_quantity ), library_reagent_batch_size);
	var kit_samples = sample_quantity + kit_waste_premium * corrected_mod;
	//console.log(kit_samples);
	//sns_cost_library = library_kit_price / samples_per_kit * kit_samples
	var sns_cost_library = library_kit_price / samples_per_kit * kit_samples;
	//console.log(sns_cost_library);
	//library_batches = CEILING(sample_quantity, library_labor_batch_size) / library_labor_batch_size
	var library_batches = (Math.ceil( sample_quantity / library_labor_batch_size ) * library_labor_batch_size ) / library_labor_batch_size;
	//console.log(library_batches);
	//rtb_cost_library = library_batches * library_prep_hours_per_batch * library_prep_labor_rate
	var rtb_cost_library = library_batches * library_prep_hours_per_batch * library_prep_labor_rate;
	//console.log(rtb_cost_library);
	//analysis_samples = MAX(sample quantity, min_samples_data_analysis)
	var analysis_samples = Math.max(sample_quantity, min_samples_data_analysis);
	//console.log(analysis_samples);
	//rtb_cost_analysis = analysis_samples * data_analysis_hours_per_sample * data_analysis_labor_rate
	var rtb_cost_analysis = analysis_samples * data_analysis_hours_per_sample * data_analysis_labor_rate;
	//console.log(rtb_cost_analysis);
	//seqruns_min = CEILING.MATH(sample_quantity / max_multiplex)
	var seqruns_min = Math.ceil(sample_quantity / max_multiplex)
	//console.log(seqruns_min);

	//runs_required = MAX(run_quantity, seqruns_min)
	var runs_required = Math.max(run_quantity, seqruns_min);
	//console.log(runs_required);

	//sns_cost_seq = sequencing_kit_price * runs_required
	var sns_cost_seq = sequencing_kit_price * runs_required;

	//rtb_cost_seq = labor_hours_per_run * sequencing_labor_rate * runs_required
	var rtb_cost_seq = labor_hours_per_run * sequencing_labor_rate * runs_required;

	//total_sns_sequencing = sns_cost_seq + sns_cost_library
	var total_sns_sequencing = sns_cost_seq + sns_cost_library;

	//total_rtb_sequencing = rtb_cost_seq + rtb_cost_library
	var total_rtb_sequencing = rtb_cost_seq + rtb_cost_library;

	//total_rtb_analysis =  rtb_cost_analysis
	var total_rtb_analysis =  rtb_cost_analysis;

	//total = total_sns_sequencing + total_rtb_sequencing + total_rtb_analysis
	var total = total_sns_sequencing + total_rtb_sequencing + total_rtb_analysis;

	//total_per_sample = total / sample_quantity
	var total_per_sample = total / sample_quantity;

	//reads_per_sample = (million_reads_per_kit * run_quantity) / sample_quantity
	var reads_per_sample = (million_reads_per_kit * run_quantity) / sample_quantity

	var actual_cost_array = [];
	actual_cost_array = [
						//sequencing_protocol_index + 1,
						sequencing_protocol,
						library_prep_platform,
						sample_quantity,
						runs_required,
						//set_precision(total_sns_sequencing),
						//set_precision(total_rtb_sequencing),
						//set_precision(total_rtb_analysis),
						set_precision(total),
						set_precision(total_per_sample),
						set_precision(reads_per_sample)
						];
	return actual_cost_array;
}
//############################################################################################################
function isFloat(val) {
	var floatRegex = /^-?\d+(?:[.,]\d*?)?$/;
	if (!floatRegex.test(val)){
		return false;
	}
	val = parseFloat(val);
	if (isNaN(val)){
		return false;
	}
	return true;
}
function get_info_from_term(term_value){
	for(var term_index = 0; term_index < term_definition_array_length; term_index++){
		if (term_value == term_definition_array[term_index]["term"]){
			return term_definition_array[term_index];

		}
		

	}
	return 0;
}
//############################################################################################################
function correct_mod(n, m) {
	return ((n % m) + m) % m;
}
//############################################################################################################
function commafy(input){
	var nStr = input + "";
	nStr = nStr.replace( /\,/g, "");
	x = nStr.split( "." );
	x1 = x[0];
	x2 = x.length > 1 ? "." + x[1] : "";
	var rgx = /(\d+)(\d{3})/;

	while ( rgx.test(x1) ) {
		x1 = x1.replace( rgx, "$1" + "," + "$2" );
	}
	input = x1 + x2;
	return input
}
//############################################################################################################
function set_precision(number){
	return number.toFixed(2);
}
//############################################################################################################