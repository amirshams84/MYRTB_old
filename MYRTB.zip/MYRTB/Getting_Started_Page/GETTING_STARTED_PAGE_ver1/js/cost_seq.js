//############################################################################################################
//#######################################GTS Sequencing cost calculator#######################################
//############################################################################################################
//By: Amir Shams
//Date: Jun/01/2016 
//Time: 15:31:54

//############################################################################################################
function get_library_prep_cost_dictionary(library_prep_platfortm){
	var library_prep_array = [];
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "DNA-Seq PCR-Free";
		library_prep_object_dictionary["library_kit_price"] = 676;
		library_prep_object_dictionary["samples_per_kit"] = 24;
		library_prep_object_dictionary["library_reagent_batch_size"] = 24;
		library_prep_object_dictionary["max_multiplex"] = 24;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 24;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 24;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "PE75-high(150-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "Neoprep nano DNA-seq";
		library_prep_object_dictionary["library_kit_price"] = 2703;
		library_prep_object_dictionary["samples_per_kit"] = 96;
		library_prep_object_dictionary["library_reagent_batch_size"] = 96;
		library_prep_object_dictionary["max_multiplex"] = 96;
		library_prep_object_dictionary["kit_waste_premium"] = 0.5;
		library_prep_object_dictionary["library_labor_batch_size"] = 24;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 24;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "PE75-high(150-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "neoprep stranded mRNA";
		library_prep_object_dictionary["library_kit_price"] = 826;
		library_prep_object_dictionary["samples_per_kit"] = 16;
		library_prep_object_dictionary["library_reagent_batch_size"] = 16;
		library_prep_object_dictionary["max_multiplex"] = 24;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 16;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 16;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "PE150-high(300-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "mRNA-Seq Stranded";
		library_prep_object_dictionary["library_kit_price"] = 2477;
		library_prep_object_dictionary["samples_per_kit"] = 48;
		library_prep_object_dictionary["library_reagent_batch_size"] = 24;
		library_prep_object_dictionary["max_multiplex"] = 24;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 12;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 24;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "PE150-high(300-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "Total RNA-seq (ribo-zero mammal)";
		library_prep_object_dictionary["library_kit_price"] = 6522;
		library_prep_object_dictionary["samples_per_kit"] = 48;
		library_prep_object_dictionary["library_reagent_batch_size"] = 24;
		library_prep_object_dictionary["max_multiplex"] = 24;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 12;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 30;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "PE150-high(300-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "Total RNA stranded (ribo-zero GOLD mammal)";
		library_prep_object_dictionary["library_kit_price"] = 7020;
		library_prep_object_dictionary["samples_per_kit"] = 48;
		library_prep_object_dictionary["library_reagent_batch_size"] = 24;
		library_prep_object_dictionary["max_multiplex"] = 24;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 12;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 30;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "PE150-high(300-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "16s rRNA gene amplicon library";
		library_prep_object_dictionary["library_kit_price"] = 1200;
		library_prep_object_dictionary["samples_per_kit"] = 24;
		library_prep_object_dictionary["library_reagent_batch_size"] = 22;
		library_prep_object_dictionary["max_multiplex"] = 24;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 24;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 30;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 0.5;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "MiSeq(600-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "outside pooled library";
		library_prep_object_dictionary["library_kit_price"] = 0;
		library_prep_object_dictionary["samples_per_kit"] = 1;
		library_prep_object_dictionary["library_reagent_batch_size"] = 1;
		library_prep_object_dictionary["max_multiplex"] = 1;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 1;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 1;
		library_prep_object_dictionary["min_samples_data_analysis"] = 1;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 0.5;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "MiSeq(600-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "ChIP-Seq";
		library_prep_object_dictionary["library_kit_price"] = 2500;
		library_prep_object_dictionary["samples_per_kit"] = 48;
		library_prep_object_dictionary["library_reagent_batch_size"] = 1;
		library_prep_object_dictionary["max_multiplex"] = 1;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 1;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 1;
		library_prep_object_dictionary["min_samples_data_analysis"] = 1;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 0.5;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "MiSeq(600-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "Illumina Total Prep beadchip";
		library_prep_object_dictionary["library_kit_price"] = 300;
		library_prep_object_dictionary["samples_per_kit"] = 12;
		library_prep_object_dictionary["library_reagent_batch_size"] = 12;
		library_prep_object_dictionary["max_multiplex"] = 12;
		library_prep_object_dictionary["kit_waste_premium"] = 1;
		library_prep_object_dictionary["library_labor_batch_size"] = 12;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 8;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "MiSeq(600-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "Nugen v2 Ovation biotin cDNA(beadchip)";
		library_prep_object_dictionary["library_kit_price"] = 1212;
		library_prep_object_dictionary["samples_per_kit"] = 12;
		library_prep_object_dictionary["library_reagent_batch_size"] = 12;
		library_prep_object_dictionary["max_multiplex"] = 12;
		library_prep_object_dictionary["kit_waste_premium"] = 1;
		library_prep_object_dictionary["library_labor_batch_size"] = 12;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 12;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "MiSeq(600-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
		library_prep_object_dictionary["library_prep_platfortm"] = "miRNA";
		library_prep_object_dictionary["library_kit_price"] = 2250;
		library_prep_object_dictionary["samples_per_kit"] = 24;
		library_prep_object_dictionary["library_reagent_batch_size"] = 24;
		library_prep_object_dictionary["max_multiplex"] = 24;
		library_prep_object_dictionary["kit_waste_premium"] = 0.3;
		library_prep_object_dictionary["library_labor_batch_size"] = 24;
		library_prep_object_dictionary["library_prep_hours_per_batch"] = 24;
		library_prep_object_dictionary["min_samples_data_analysis"] = 6;
		library_prep_object_dictionary["data_analysis_hours_per_sample"] = 1;
		library_prep_object_dictionary["library_prep_labor_rate"] = 15;
		library_prep_object_dictionary["data_analysis_labor_rate"] = 15;
		library_prep_object_dictionary["optimal_protocol"] = "MiSeq(600-cycles)";
	library_prep_array.push(library_prep_object_dictionary);
	//###########################################################################################################
	var library_prep_object_dictionary = {};
	var keys  = Object.keys(library_prep_array);
	for(var i=0;i<keys.length;i++){
		if (library_prep_platfortm == library_prep_array[i]["library_prep_platfortm"]){
			library_prep_object_dictionary =  library_prep_array[i];
		}
	}
	return library_prep_object_dictionary;

}
//############################################################################################################
function get_sequencing_cost_dictionary(sequencing_protocol){
	var sequencing_cost_array = [];
	var sequencing_cost_object_dictionary = {};
		sequencing_cost_object_dictionary["sequencing_protocol"] = "SE75-high(75-cycles)"; 
		sequencing_cost_object_dictionary["sequencing_kit_price"] = 1269;
		sequencing_cost_object_dictionary["million_reads_per_kit"] = 400;
		sequencing_cost_object_dictionary["labor_hours_per_run"] = 6;
		sequencing_cost_object_dictionary["sequencing_labor_rate"] = 15;
	sequencing_cost_array.push(sequencing_cost_object_dictionary);
	var sequencing_cost_object_dictionary = {};
		sequencing_cost_object_dictionary["sequencing_protocol"] = "PE75-mid(150-cycles)"; 
		sequencing_cost_object_dictionary["sequencing_kit_price"] = 948;
		sequencing_cost_object_dictionary["million_reads_per_kit"] = 130;
		sequencing_cost_object_dictionary["labor_hours_per_run"] = 6;
		sequencing_cost_object_dictionary["sequencing_labor_rate"] = 15;
	sequencing_cost_array.push(sequencing_cost_object_dictionary);
	var sequencing_cost_object_dictionary = {};
		sequencing_cost_object_dictionary["sequencing_protocol"] = "PE75-high(150-cycles)"; 
		sequencing_cost_object_dictionary["sequencing_kit_price"] = 2438;
		sequencing_cost_object_dictionary["million_reads_per_kit"] = 400;
		sequencing_cost_object_dictionary["labor_hours_per_run"] = 6;
		sequencing_cost_object_dictionary["sequencing_labor_rate"] = 15;
	sequencing_cost_array.push(sequencing_cost_object_dictionary);
	var sequencing_cost_object_dictionary = {};
		sequencing_cost_object_dictionary["sequencing_protocol"] = "PE150-mid(300-cycles)"; 
		sequencing_cost_object_dictionary["sequencing_kit_price"] = 1517;
		sequencing_cost_object_dictionary["million_reads_per_kit"] = 130;
		sequencing_cost_object_dictionary["labor_hours_per_run"] = 6;
		sequencing_cost_object_dictionary["sequencing_labor_rate"] = 15;
	sequencing_cost_array.push(sequencing_cost_object_dictionary);
	var sequencing_cost_object_dictionary = {};
		sequencing_cost_object_dictionary["sequencing_protocol"] = "PE150-high(300-cycles)"; 
		sequencing_cost_object_dictionary["sequencing_kit_price"] = 3890;
		sequencing_cost_object_dictionary["million_reads_per_kit"] = 400;
		sequencing_cost_object_dictionary["labor_hours_per_run"] = 6;
		sequencing_cost_object_dictionary["sequencing_labor_rate"] = 15;
	sequencing_cost_array.push(sequencing_cost_object_dictionary);
	var sequencing_cost_object_dictionary = {};
		sequencing_cost_object_dictionary["sequencing_protocol"] = "MiSeq(600-cycles)"; 
		sequencing_cost_object_dictionary["sequencing_kit_price"] = 1394;
		sequencing_cost_object_dictionary["million_reads_per_kit"] = 25;
		sequencing_cost_object_dictionary["labor_hours_per_run"] = 6;
		sequencing_cost_object_dictionary["sequencing_labor_rate"] = 15;
	sequencing_cost_array.push(sequencing_cost_object_dictionary);
	//############################################################
	var sequencing_cost_object_dictionary = {};
	var keys  = Object.keys(sequencing_cost_array);
	for(var i=0;i<keys.length;i++){
		if (sequencing_protocol == sequencing_cost_array[i]["sequencing_protocol"]){
			sequencing_cost_object_dictionary =  sequencing_cost_array[i];
		}
	}
	return sequencing_cost_object_dictionary;

}
//############################################################################################################
function merge_table_with_html(library_prep_platfortm, sample_quantity, run_quantity, table_id){
	//Removing existing table element
	//console.log(library_prep_platfortm);
	var elem =document.getElementById(table_id).lastChild;
		elem.parentNode.removeChild(elem);
	
	var table_body_code = generate_table(library_prep_platfortm, sample_quantity, run_quantity);
	//document.getElementById(table_id).getElementsByTagName('tbody')[0] = table_body_code;
	document.getElementById(table_id).appendChild(table_body_code);
	

}
//############################################################################################################
function generate_table(library_prep_platfortm, sample_quantity, run_quantity){
	var instanse_name_of_sequencing_protocol = [
		"SE75-high(75-cycles)",
		"PE75-mid(150-cycles)",
		"PE75-high(150-cycles)",
		"PE150-mid(300-cycles)",
		"PE150-high(300-cycles)",
		"MiSeq(600-cycles)"
	];
	var library_prep_platform_dictionary = get_library_prep_cost_dictionary(library_prep_platfortm);
	//load into memory variables name dynamically
	for(var library_prep_platform_dictionary_key in library_prep_platform_dictionary) {
		window[library_prep_platform_dictionary_key] = library_prep_platform_dictionary[library_prep_platform_dictionary_key];
	}
	var html_tbdy = document.createElement("tbody");
		//html_tbdy.style.fontSize = "small";

	for(var sequencing_protocol_index = 0; sequencing_protocol_index < instanse_name_of_sequencing_protocol.length; sequencing_protocol_index++){
			var html_tr = document.createElement("tr");
			if (library_prep_platform_dictionary["optimal_protocol"] == instanse_name_of_sequencing_protocol[sequencing_protocol_index]){
				html_tr.style.backgroundColor = 'yellow';
			}
			//console.log(instanse_name_of_Sequencing_protocol[each_protocol_index]);
			var cells = [];  
			var calcs = [];
			var actual_cost_array = [];
			actual_cost_array = calculate_actual_cost(library_prep_platfortm, sample_quantity, run_quantity, sequencing_protocol_index, instanse_name_of_sequencing_protocol[sequencing_protocol_index]);
			//console.log(actual_cost_array)
			var calcs_length = actual_cost_array.length;
			for (var i=0; i <calcs_length; i++){
				if (isFloat(actual_cost_array[i]) ){
					if (i > 3 & i < calcs_length - 1 ){
						cells.push('$' + commafy(actual_cost_array[i]));
					}
					else{

						cells.push(commafy(actual_cost_array[i]));
					}
				}
				else{
					cells.push(actual_cost_array[i]);
				}
			}
			
			for(var j=0;j < cells.length;j++){
				var html_td = document.createElement("td");
					html_td.appendChild(document.createTextNode(cells[j]))
					html_td.style.textAlign = "center";
					html_tr.appendChild(html_td);
					
			}
			
			html_tbdy.appendChild(html_tr);
		};
	return html_tbdy;

}
//############################################################################################################
function calculate_actual_cost(library_prep_platfortm, sample_quantity, run_quantity, sequencing_protocol_index, sequencing_protocol){
	//########################################
	//conversion
	sample_quantity = parseInt(sample_quantity);
	run_quantity = parseInt(run_quantity);
	//########################################
	//Dynamic variable loader
	var library_prep_platform_dictionary = get_library_prep_cost_dictionary(library_prep_platfortm);
	for(var library_prep_platform_dictionary_key in library_prep_platform_dictionary) {
		window[library_prep_platform_dictionary_key] = library_prep_platform_dictionary[library_prep_platform_dictionary_key];
	}
	var sequencing_protocol_dictionary = get_sequencing_cost_dictionary(sequencing_protocol);
	for(var sequencing_protocol_dictionary_key in sequencing_protocol_dictionary) {
		window[sequencing_protocol_dictionary_key] = sequencing_protocol_dictionary[sequencing_protocol_dictionary_key];
	}
	//#######################################
	//Main Calculation section

	
	//kit_samples = sample_quantity + kit_waste_premium * MOD(library_reagent_batch_size - sample_quantity, library_reagent_batch_size)
	var corrected_mod = correct_mod(( library_reagent_batch_size - sample_quantity ), library_reagent_batch_size);
	var kit_samples = sample_quantity + kit_waste_premium * corrected_mod;
	//console.log(kit_samples);
	//sns_cost_library = library_kit_price / samples_per_kit * kit_samples
	var sns_cost_library = library_kit_price / samples_per_kit * kit_samples;
	//console.log(sns_cost_library);
	//library_batches = CEILING(sample_quantity, library_labor_batch_size) / library_labor_batch_size
	var library_batches = (Math.ceil( sample_quantity / library_labor_batch_size ) * library_labor_batch_size ) / library_labor_batch_size;
	//console.log(library_batches);
	//rtb_cost_library = library_batches * library_prep_hours_per_batch * library_prep_labor_rate
	var rtb_cost_library = library_batches * library_prep_hours_per_batch * library_prep_labor_rate;
	//console.log(rtb_cost_library);
	//analysis_samples = MAX(sample quantity, min_samples_data_analysis)
	var analysis_samples = Math.max(sample_quantity, min_samples_data_analysis);
	//console.log(analysis_samples);
	//rtb_cost_analysis = analysis_samples * data_analysis_hours_per_sample * data_analysis_labor_rate
	var rtb_cost_analysis = analysis_samples * data_analysis_hours_per_sample * data_analysis_labor_rate;
	//console.log(rtb_cost_analysis);
	//seqruns_min = CEILING.MATH(sample_quantity / max_multiplex)
	var seqruns_min = Math.ceil(sample_quantity / max_multiplex)
	//console.log(seqruns_min);

	//runs_required = MAX(run_quantity, seqruns_min)
	var runs_required = Math.max(run_quantity, seqruns_min);
	//console.log(runs_required);

	//sns_cost_seq = sequencing_kit_price * runs_required
	var sns_cost_seq = sequencing_kit_price * runs_required;

	//rtb_cost_seq = labor_hours_per_run * sequencing_labor_rate * runs_required
	var rtb_cost_seq = labor_hours_per_run * sequencing_labor_rate * runs_required;

	//total_sns_sequencing = sns_cost_seq + sns_cost_library
	var total_sns_sequencing = sns_cost_seq + sns_cost_library;

	//total_rtb_sequencing = rtb_cost_seq + rtb_cost_library
	var total_rtb_sequencing = rtb_cost_seq + rtb_cost_library;

	//total_rtb_analysis =  rtb_cost_analysis
	var total_rtb_analysis =  rtb_cost_analysis;

	//total = total_sns_sequencing + total_rtb_sequencing + total_rtb_analysis
	var total = total_sns_sequencing + total_rtb_sequencing + total_rtb_analysis;

	//total_per_sample = total / sample_quantity
	var total_per_sample = total / sample_quantity;

	//reads_per_sample = (million_reads_per_kit * run_quantity) / sample_quantity
	var reads_per_sample = (million_reads_per_kit * run_quantity) / sample_quantity

	var actual_cost_array = [];
	actual_cost_array = [
						//sequencing_protocol_index + 1,
						sequencing_protocol,
						library_prep_platfortm,
						sample_quantity,
						runs_required,
						//set_precision(total_sns_sequencing),
						//set_precision(total_rtb_sequencing),
						//set_precision(total_rtb_analysis),
						set_precision(total),
						set_precision(total_per_sample),
						set_precision(reads_per_sample)
						];
	return actual_cost_array;
}
//############################################################################################################
function isFloat(val) {
	var floatRegex = /^-?\d+(?:[.,]\d*?)?$/;
	if (!floatRegex.test(val)){
		return false;
	}
	val = parseFloat(val);
	if (isNaN(val)){
		return false;
	}
	return true;
}
//############################################################################################################
function correct_mod(n, m) {
	return ((n % m) + m) % m;
}
//############################################################################################################
function commafy(input){
	var nStr = input + "";
	nStr = nStr.replace( /\,/g, "");
	x = nStr.split( "." );
	x1 = x[0];
	x2 = x.length > 1 ? "." + x[1] : "";
	var rgx = /(\d+)(\d{3})/;

	while ( rgx.test(x1) ) {
		x1 = x1.replace( rgx, "$1" + "," + "$2" );
	}
	input = x1 + x2;
	return input
}
//############################################################################################################
function set_precision(number){
	return number.toFixed(2);
}
//############################################################################################################